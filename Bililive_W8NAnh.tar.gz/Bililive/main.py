import requests

url = 'https://rr5---sn-p5qs7nsr.googlevideo.com/videoplayback?expire=1678727682&ei=ogUPZMCGGf-7ir4P5smg8A8&ip=198.181.163.116&id=o-AFuGQ0NWlCo9Jz8feEi40VNL8H4e4WeidhVLsS3vEtr_&itag=22&source=youtube&requiressl=yes&mh=j1&mm=31%2C26&mn=sn-p5qs7nsr%2Csn-vgqsknlk&ms=au%2Conr&mv=m&mvi=5&pl=24&initcwndbps=1613750&spc=H3gIhr6k062cCGKfRo05jp_5XBrLbBxNtcKAzPQ88JS94wcriw&vprv=1&mime=video%2Fmp4&ns=7FejOFfAebOOdx4Wl-erAlYL&cnr=14&ratebypass=yes&dur=7134.122&lmt=1671427760536078&mt=1678705764&fvip=1&fexp=24007246&c=WEB&txp=4432434&n=S-uPNO-nzGZGIA&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cspc%2Cvprv%2Cmime%2Cns%2Ccnr%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRQIgbxPLvKF7XmS26Scqx4xcMUWcFhyQ9rLIivS10dMBd7YCIQDYh2j7dk7nj-o1QYZxhbvet39v3iWuTgZrNjDSWYFmCg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRAIgOudxmY3rP48TtBePxAcYhuogCi2RdmppCouhtXrLmtkCIGfbahJhdrXo4waG8f2-gShGm2XxT3vzjnS7BKhob4KS&title=Tokyo%20Yomiuri%20Land%20Christmas%20Lights%202022%E3%83%BB4K%20HDR'

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
}
response = requests.get(url=url,headers=headers)

print()
with open('test.mp4','wb') as f:
    f.write(response.content)
